# CREEM resubmission checklist

What CREEM asked for, and where it now lives on the site.

| CREEM request | Done | Where |
|---|---|---|
| Finalized, store-specific Terms | Yes | `terms.html` (names Creem as Merchant of Record, licenses, cancellation, apps, ServiceLock) |
| Finalized, store-specific Privacy Policy | Yes | `privacy.html` (names Creem, Netlify, GitHub, Supabase, AI providers) |
| NSFW prohibition and filtering policy for AI tools | Yes | `acceptable-use.html`, section 8 of `terms.html`, and a notice on every AI plugin page, both app pages, Home, and Products |
| Same support email in store and website | Yes | yomi@lehemnetwork.org on every page, footer, policies, and contact form |
| Subsidiary of Lehem Network stated clearly | Yes | Home hero + band, About, Contact, footer on every page, all policies |

## Before you resubmit (things only you can do)

1. In CREEM store settings, keep the support email as yomi@lehemnetwork.org (it must match the site).
2. Fill in the real prices where the site says **"Price shown at checkout"** (Earshelf Plus and Pro) and **"$__ one-time"** (AgentBridge AI Pro), and paste each product's Creem checkout link where the HTML says `TODO: replace with Creem checkout link URL`.
3. Paste the live Earshelf address where the Earshelf buttons say `TODO` (both are on `apps/earshelf.html`).
4. Check the policies once with someone who can confirm your exact legal entity name, registered address, and governing-law country, and add them to the Terms (sections 1 and 19) and Privacy Policy (section 14).
5. Make the NSFW filtering true in the code: before any request reaches an AI model, run it through that provider's moderation endpoint (for example OpenAI's free Moderation API) and refuse flagged input. VisionTag AI (images) and the Earshelf and Tapestry servers are the priority.
6. Earshelf's billing code still talks to Lemon Squeezy (`packages/billing`, `LS_*` settings, webhook). It needs a CREEM webhook equivalent before paid plans can work.
7. Redeploy, then open apps.lehemnetwork.org/terms, /privacy, /refund and /acceptable-use in a private window to confirm they load.
